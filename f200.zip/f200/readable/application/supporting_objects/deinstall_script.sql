begin
    for r_table_info in (
        select TABLE_NAME
          from USER_TABLES
         where TABLE_NAME in ('APEX_MEETUP_DICT_STATUSES', 'APEX_MEETUP_USERS', 'APEX_MEETUP_ITEMS', 'APEX_MEETUP_ORDERS')
    )
    loop
        execute immediate 'drop table ' || r_table_info.TABLE_NAME || ' cascade constraints';
    end loop;
end;
/