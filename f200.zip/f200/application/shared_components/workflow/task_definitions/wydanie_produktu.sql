prompt --application/shared_components/workflow/task_definitions/wydanie_produktu
begin
--   Manifest
--     TASK_DEF: Wydanie produktu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.10'
,p_default_workspace_id=>30000567201644221
,p_default_application_id=>200
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXMEETUP'
);
wwv_flow_imp_shared.create_task_def(
 p_id=>wwv_flow_imp.id(40420041245308443)
,p_name=>'Wydanie produktu'
,p_static_id=>'ITEM_ISSUING_TASK'
,p_subject=>unistr('Wydanie sprz\0119tu &NAME. (liczba sztuk: &QUANTITY.) dla &FULL_NAME.')
,p_task_type=>'ACTION'
,p_priority=>3
,p_expiration_policy=>'NONE'
,p_max_renewal_count=>3
,p_actions_sql_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select i.NAME',
'     , o.QUANTITY',
'     , u.FULL_NAME',
'     , o.CREATED_BY as ORDER_CREATOR',
'  from APEX_MEETUP_ORDERS o ',
'  join APEX_MEETUP_ITEMS  i on o.ITEM_ID = i.ID',
'  join APEX_MEETUP_USERS  u on o.CREATED_BY = u.LOGIN',
' where o.ID = :APEX$TASK_PK'))
,p_initiator_can_complete=>false
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(40420298997308446)
,p_task_def_id=>wwv_flow_imp.id(40420041245308443)
,p_participant_type=>'POTENTIAL_OWNER'
,p_identity_type=>'USER'
,p_value_type=>'SQL_QUERY'
,p_value=>'select LOGIN from APEX_MEETUP_USERS where IS_OFFICE = ''Y'''
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(40420639846308448)
,p_task_def_id=>wwv_flow_imp.id(40420041245308443)
,p_participant_type=>'BUSINESS_ADMIN'
,p_identity_type=>'USER'
,p_value_type=>'SQL_QUERY'
,p_value=>'select LOGIN from APEX_MEETUP_USERS where IS_ADMIN = ''Y'''
);
wwv_flow_imp.component_end;
end;
/
