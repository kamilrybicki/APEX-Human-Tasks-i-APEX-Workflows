prompt --application/shared_components/workflow/task_definitions/zgoda_przełożonego_na_wydanie_sprzętu
begin
--   Manifest
--     TASK_DEF: Zgoda przełożonego na wydanie sprzętu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.10'
,p_default_workspace_id=>30000567201644221
,p_default_application_id=>200
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXMEETUP'
);
wwv_flow_imp_shared.create_task_def(
 p_id=>wwv_flow_imp.id(39607677627082379)
,p_name=>unistr('Zgoda prze\0142o\017Conego na wydanie sprz\0119tu')
,p_static_id=>'ITEM_ORDER_APPROVAL_TASK'
,p_subject=>unistr('Zgoda o wydanie sprz\0119tu &NAME. (liczba sztuk: &QUANTITY.) dla &FULL_NAME.')
,p_task_type=>'APPROVAL'
,p_priority=>3
,p_expiration_policy=>'NONE'
,p_max_renewal_count=>3
,p_details_link_target=>'f?p=&APP_ID.:1000:&SESSION.::&DEBUG.:RP,1000:P1000_TASK_ID:&TASK_ID.'
,p_actions_sql_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select i.NAME',
'     , o.QUANTITY',
'     , u.FULL_NAME',
'     , o.CREATED_BY as ORDER_CREATOR',
'  from APEX_MEETUP_ORDERS o ',
'  join APEX_MEETUP_ITEMS  i on o.ITEM_ID = i.ID',
'  join APEX_MEETUP_USERS  u on o.CREATED_BY = u.LOGIN',
' where o.ID = :APEX$TASK_PK'))
,p_initiator_can_complete=>false
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(39728199060573120)
,p_task_def_id=>wwv_flow_imp.id(39607677627082379)
,p_participant_type=>'BUSINESS_ADMIN'
,p_identity_type=>'USER'
,p_value_type=>'SQL_QUERY'
,p_value=>'select LOGIN from APEX_MEETUP_USERS where IS_ADMIN = ''Y'''
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(39728411474573123)
,p_task_def_id=>wwv_flow_imp.id(39607677627082379)
,p_participant_type=>'POTENTIAL_OWNER'
,p_identity_type=>'USER'
,p_value_type=>'SQL_QUERY'
,p_value=>'select SUPERVISOR_LOGIN from APEX_MEETUP_USERS where LOGIN = :ORDER_CREATOR'
);
wwv_flow_imp.component_end;
end;
/
