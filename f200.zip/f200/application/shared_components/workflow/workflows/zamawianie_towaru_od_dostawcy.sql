prompt --application/shared_components/workflow/workflows/zamawianie_towaru_od_dostawcy
begin
--   Manifest
--     WORKFLOW: Zamawianie towaru od dostawcy
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.10'
,p_default_workspace_id=>30000567201644221
,p_default_application_id=>200
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXMEETUP'
);
wwv_flow_imp_shared.create_workflow(
 p_id=>wwv_flow_imp.id(39003656932305426)
,p_name=>'Zamawianie towaru od dostawcy'
,p_static_id=>'ITEM_ORDER_WORKFLOW'
,p_title=>'Zamawianie towaru od dostawcy'
);
wwv_flow_imp_shared.create_workflow_version(
 p_id=>wwv_flow_imp.id(43035535298655707)
,p_workflow_id=>wwv_flow_imp.id(39003656932305426)
,p_version=>'v1.0.1'
,p_state=>'DEVELOPMENT'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(43035652588655708)
,p_workflow_version_id=>wwv_flow_imp.id(43035535298655707)
,p_name=>'Start'
,p_static_id=>'New'
,p_display_sequence=>10
,p_activity_type=>'NATIVE_WORKFLOW_START'
,p_diagram=>'{"position":{"x":700,"y":970},"z":1}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(43035895708655710)
,p_workflow_version_id=>wwv_flow_imp.id(43035535298655707)
,p_name=>'End'
,p_static_id=>'New_2'
,p_display_sequence=>20
,p_activity_type=>'NATIVE_WORKFLOW_END'
,p_attribute_01=>'COMPLETED'
,p_diagram=>'{"position":{"x":1240,"y":970},"z":2}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(43035925938655711)
,p_workflow_version_id=>wwv_flow_imp.id(43035535298655707)
,p_name=>unistr('Zaktualizuj liczb\0119 dost\0119pnych przedmiot\00F3w (+5)')
,p_static_id=>'New_3'
,p_display_sequence=>30
,p_activity_type=>'NATIVE_PLSQL'
,p_activity_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('-- SYMULACJA ZAM\00D3WIENIA TOWARU U DOSTAWCY --'),
'dbms_session.sleep(30); -- 30 sekund',
'',
'update APEX_MEETUP_ITEMS',
'   set AVAILABLE_QUANTITY = AVAILABLE_QUANTITY + 5',
' where ID = :APEX$WORKFLOW_DETAIL_PK;',
'commit;'))
,p_activity_code_language=>'PLSQL'
,p_location=>'LOCAL'
,p_diagram=>'{"position":{"x":890,"y":960},"z":3}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(43035703721655709)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(43035652588655708)
,p_to_activity_id=>wwv_flow_imp.id(43035925938655711)
,p_diagram=>'{"source":{},"target":{"name":"topLeft","args":{"dx":"0%","dy":"50%","rotate":true}},"vertices":[],"z":4,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(43036072117655712)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(43035925938655711)
,p_to_activity_id=>wwv_flow_imp.id(43035895708655710)
,p_diagram=>'{"source":{},"target":{},"vertices":[],"z":5,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_participant(
 p_id=>wwv_flow_imp.id(43036186185655713)
,p_workflow_version_id=>wwv_flow_imp.id(43035535298655707)
,p_participant_type=>'ADMIN'
,p_name=>'Workflow Admin'
,p_identity_type=>'USER'
,p_value_type=>'SQL_QUERY'
,p_value=>'select LOGIN from APEX_MEETUP_USERS where IS_ADMIN = ''Y'''
);
wwv_flow_imp_shared.create_workflow_participant(
 p_id=>wwv_flow_imp.id(43036264693655714)
,p_workflow_version_id=>wwv_flow_imp.id(43035535298655707)
,p_participant_type=>'OWNER'
,p_name=>'Workflow Owner'
,p_identity_type=>'USER'
,p_value_type=>'SQL_QUERY'
,p_value=>'select LOGIN from APEX_MEETUP_USERS where IS_ADMIN = ''Y'''
);
wwv_flow_imp.component_end;
end;
/
