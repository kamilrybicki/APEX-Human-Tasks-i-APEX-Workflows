prompt --application/shared_components/workflow/workflows/wniosek_o_sprzęt
begin
--   Manifest
--     WORKFLOW: Wniosek o sprzęt
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.10'
,p_default_workspace_id=>30000567201644221
,p_default_application_id=>200
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXMEETUP'
);
wwv_flow_imp_shared.create_workflow(
 p_id=>wwv_flow_imp.id(11079795990642219)
,p_name=>unistr('Wniosek o sprz\0119t')
,p_static_id=>'EQUIPMENT_ORDER_WORKFLOW'
,p_title=>unistr('Wniosek o sprz\0119t')
);
wwv_flow_imp_shared.create_workflow_version(
 p_id=>wwv_flow_imp.id(13680274895120314)
,p_workflow_id=>wwv_flow_imp.id(11079795990642219)
,p_version=>'v1.0.2'
,p_state=>'DEVELOPMENT'
,p_query_type=>'SQL'
,p_query_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ITEM_ID  as ORDERED_ITEM_ID',
'     , QUANTITY as ORDERED_ITEM_QUANTITY',
'  from APEX_MEETUP_ORDERS',
' where ID = :APEX$WORKFLOW_DETAIL_PK;'))
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(13683550720120347)
,p_workflow_version_id=>wwv_flow_imp.id(13680274895120314)
,p_label=>'Rezultat akceptacji wniosku'
,p_static_id=>'SUPERVISOR_APPROVAL_TASK_OUTCOME'
,p_direction=>'VARIABLE'
,p_data_type=>'VARCHAR2'
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(13680338088120315)
,p_workflow_version_id=>wwv_flow_imp.id(13680274895120314)
,p_name=>'Start'
,p_static_id=>'WORKFLOW_START'
,p_display_sequence=>10
,p_activity_type=>'NATIVE_WORKFLOW_START'
,p_diagram=>'{"position":{"x":-590,"y":-60},"z":1}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(13680530956120317)
,p_workflow_version_id=>wwv_flow_imp.id(13680274895120314)
,p_name=>unistr('Aktualizacja liczby zam\00F3wionych sztuk')
,p_static_id=>'ORDERED_QUANTITY_UPDATE'
,p_display_sequence=>20
,p_activity_type=>'NATIVE_PLSQL'
,p_activity_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update APEX_MEETUP_ITEMS',
'   set ORDERED_QUANTITY = ORDERED_QUANTITY + :ORDERED_ITEM_QUANTITY',
' where ID = :ORDERED_ITEM_ID;'))
,p_activity_code_language=>'PLSQL'
,p_location=>'LOCAL'
,p_diagram=>'{"position":{"x":-480,"y":-60},"z":2}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(13680721258120319)
,p_workflow_version_id=>wwv_flow_imp.id(13680274895120314)
,p_name=>unistr('Zmniejszenie liczby zam\00F3wionych sztuk')
,p_static_id=>'ORDERED_QUANTITY_UPDATE_3'
,p_display_sequence=>30
,p_activity_type=>'NATIVE_PLSQL'
,p_activity_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update APEX_MEETUP_ITEMS',
'   set ORDERED_QUANTITY = ORDERED_QUANTITY - :ORDERED_ITEM_QUANTITY',
' where ID = :ORDERED_ITEM_ID;'))
,p_activity_code_language=>'PLSQL'
,p_location=>'LOCAL'
,p_diagram=>'{"position":{"x":70,"y":-210},"z":3}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(13680903273120321)
,p_workflow_version_id=>wwv_flow_imp.id(13680274895120314)
,p_name=>unistr('Aktualizacja liczby dost\0119pnych i zam\00F3wionych sztuk')
,p_static_id=>'ORDERED_QUANTITY_UPDATE_2'
,p_display_sequence=>40
,p_activity_type=>'NATIVE_PLSQL'
,p_activity_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update APEX_MEETUP_ITEMS',
'   set ORDERED_QUANTITY = ORDERED_QUANTITY - :ORDERED_ITEM_QUANTITY',
'     , AVAILABLE_QUANTITY = AVAILABLE_QUANTITY - :ORDERED_ITEM_QUANTITY',
' where ID = :ORDERED_ITEM_ID;'))
,p_activity_code_language=>'PLSQL'
,p_location=>'LOCAL'
,p_diagram=>'{"position":{"x":1670,"y":-70},"z":4}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(13681179025120323)
,p_workflow_version_id=>wwv_flow_imp.id(13680274895120314)
,p_name=>unistr('Zmie\0144 status wniosku na w trakcie zamawiania')
,p_static_id=>'ORDERED_QUANTITY_UPDATE_1'
,p_display_sequence=>50
,p_activity_type=>'NATIVE_PLSQL'
,p_activity_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update APEX_MEETUP_ORDERS',
'   set STATUS_CODE = ''ORDERING_PROCESS_IN_PROGRESS''',
' where ID = :APEX$WORKFLOW_DETAIL_PK;'))
,p_activity_code_language=>'PLSQL'
,p_location=>'LOCAL'
,p_diagram=>'{"position":{"x":550,"y":160},"z":5}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(13681355573120325)
,p_workflow_version_id=>wwv_flow_imp.id(13680274895120314)
,p_name=>unistr('Zmie\0144 status wniosku na gotowy do odbioru')
,p_static_id=>'ORDERED_QUANTITY_UPDATE_1_1'
,p_display_sequence=>60
,p_activity_type=>'NATIVE_PLSQL'
,p_activity_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update APEX_MEETUP_ORDERS',
'   set STATUS_CODE = ''READY_FOR_PICK_UP''',
' where ID = :APEX$WORKFLOW_DETAIL_PK;'))
,p_activity_code_language=>'PLSQL'
,p_location=>'LOCAL'
,p_diagram=>'{"position":{"x":820,"y":-60},"z":6}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(13681581564120327)
,p_workflow_version_id=>wwv_flow_imp.id(13680274895120314)
,p_name=>unistr('Akceptacja prze\0142o\017Conego')
,p_static_id=>'New'
,p_display_sequence=>70
,p_activity_type=>'NATIVE_CREATE_TASK'
,p_attribute_01=>wwv_flow_imp.id(39607677627082379)
,p_attribute_05=>'APEX$WORKFLOW_DETAIL_PK'
,p_attribute_08=>'SUPERVISOR_APPROVAL_TASK_OUTCOME'
,p_diagram=>'{"position":{"x":-200,"y":-60},"z":7}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(13681776122120329)
,p_workflow_version_id=>wwv_flow_imp.id(13680274895120314)
,p_name=>'End'
,p_static_id=>'WORKFLOW_END'
,p_display_sequence=>80
,p_activity_type=>'NATIVE_WORKFLOW_END'
,p_attribute_01=>'COMPLETED'
,p_diagram=>'{"position":{"x":2240,"y":-60},"z":8}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(13681806329120330)
,p_workflow_version_id=>wwv_flow_imp.id(13680274895120314)
,p_name=>unistr('Czy wniosek zosta\0142 zaakceptowany?')
,p_static_id=>'New_1'
,p_display_sequence=>90
,p_activity_type=>'NATIVE_WORKFLOW_SWITCH'
,p_attribute_01=>'CHECK_WF_VARIABLE'
,p_attribute_10=>'SUPERVISOR_APPROVAL_TASK_OUTCOME'
,p_diagram=>'{"position":{"x":80,"y":-60},"z":9}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(13682166251120333)
,p_workflow_version_id=>wwv_flow_imp.id(13680274895120314)
,p_name=>'Wniosek odrzucony - koniec procesu'
,p_static_id=>'New_2'
,p_display_sequence=>100
,p_activity_type=>'NATIVE_WORKFLOW_END'
,p_attribute_01=>'COMPLETED'
,p_diagram=>'{"position":{"x":160,"y":-440},"z":10}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(13682213648120334)
,p_workflow_version_id=>wwv_flow_imp.id(13680274895120314)
,p_name=>unistr('Zmie\0144 status wniosku na odrzucony')
,p_static_id=>'New_3'
,p_display_sequence=>110
,p_activity_type=>'NATIVE_PLSQL'
,p_activity_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update APEX_MEETUP_ORDERS',
'   set STATUS_CODE = ''REJECTED''',
' where ID = :APEX$WORKFLOW_DETAIL_PK;'))
,p_activity_code_language=>'PLSQL'
,p_location=>'LOCAL'
,p_diagram=>'{"position":{"x":80,"y":-340},"z":11}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(13682431264120336)
,p_workflow_version_id=>wwv_flow_imp.id(13680274895120314)
,p_name=>unistr('Czy liczba dost\0119pnych sztuk >= liczba zam\00F3wionych sztuk?')
,p_static_id=>'New_4'
,p_display_sequence=>120
,p_activity_type=>'NATIVE_WORKFLOW_SWITCH'
,p_attribute_01=>'TRUE_FALSE_CHECK'
,p_attribute_03=>'ROWS_RETURNED'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from APEX_MEETUP_ITEMS',
' where ID = :ORDERED_ITEM_ID',
'   and AVAILABLE_QUANTITY >= ORDERED_QUANTITY'))
,p_diagram=>'{"position":{"x":510,"y":-70},"z":12}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(13682746301120339)
,p_workflow_version_id=>wwv_flow_imp.id(13680274895120314)
,p_name=>'Zamawianie towaru i przygotowanie'
,p_static_id=>'New_5'
,p_display_sequence=>130
,p_activity_type=>'NATIVE_INVOKE_WF'
,p_attribute_01=>wwv_flow_imp.id(39003656932305426)
,p_attribute_03=>'ORDERED_ITEM_ID'
,p_attribute_05=>'Y'
,p_attribute_06=>'RESUME'
,p_diagram=>'{"position":{"x":240,"y":170},"z":13}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(13682963534120341)
,p_workflow_version_id=>wwv_flow_imp.id(13680274895120314)
,p_name=>unistr('Wy\015Blij wiadomo\015B\0107 do wnioskuj\0105cego')
,p_static_id=>'New_7'
,p_display_sequence=>140
,p_query_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select i.NAME',
'     , o.QUANTITY',
'     , u.EMAIL as REQUESTOR_EMAIL',
'  from APEX_MEETUP_ORDERS o ',
'  join APEX_MEETUP_ITEMS  i on o.ITEM_ID = i.ID',
'  join APEX_MEETUP_USERS  u on o.CREATED_BY = u.LOGIN',
' where o.ID = :APEX$WORKFLOW_DETAIL_PK'))
,p_activity_type=>'NATIVE_SEND_EMAIL'
,p_attribute_01=>'&APP_EMAIL.'
,p_attribute_02=>'&REQUESTOR_EMAIL.'
,p_attribute_06=>unistr('Zam\00F3wiony sprz\0119t &NAME. (liczba sztuk: &QUANTITY.) czeka na odbi\00F3r')
,p_attribute_07=>unistr('Cze\015B\0107, zam\00F3wiony sprz\0119t &NAME. (liczba sztuk: &QUANTITY.) czeka na odbi\00F3r.')
,p_attribute_08=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Cze\015B\0107, <br/>'),
unistr('zam\00F3wiony sprz\0119t &NAME. (liczba sztuk: &QUANTITY.) czeka na odbi\00F3r.')))
,p_attribute_10=>'Y'
,p_diagram=>'{"position":{"x":1100,"y":-60},"z":14}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(13683143034120343)
,p_workflow_version_id=>wwv_flow_imp.id(13680274895120314)
,p_name=>unistr('Wy\015Blij potwierdzenie odebrania do wnioskuj\0105cego')
,p_static_id=>'New_7_1'
,p_display_sequence=>150
,p_query_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select i.NAME',
'     , o.QUANTITY',
'     , u.EMAIL as REQUESTOR_EMAIL',
'  from APEX_MEETUP_ORDERS o ',
'  join APEX_MEETUP_ITEMS  i on o.ITEM_ID = i.ID',
'  join APEX_MEETUP_USERS  u on o.CREATED_BY = u.LOGIN',
' where o.ID = :APEX$WORKFLOW_DETAIL_PK'))
,p_activity_type=>'NATIVE_SEND_EMAIL'
,p_attribute_01=>'&APP_EMAIL.'
,p_attribute_02=>'&REQUESTOR_EMAIL.'
,p_attribute_06=>unistr('Zam\00F3wiony sprz\0119t &NAME. (liczba sztuk: &QUANTITY.) zosta\0142 odebrany.')
,p_attribute_07=>unistr('Cze\015B\0107, potwierdzamy, \017Ce zam\00F3wiony sprz\0119t &NAME. (liczba sztuk: &QUANTITY.) zosta\0142 przez Ciebie odebrany.')
,p_attribute_08=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Cze\015B\0107, <br/>'),
unistr('potwierdzamy, \017Ce zam\00F3wiony sprz\0119t &NAME. (liczba sztuk: &QUANTITY.) zosta\0142 przez Ciebie odebrany.')))
,p_attribute_10=>'Y'
,p_diagram=>'{"position":{"x":1960,"y":-70},"z":15}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(13683342662120345)
,p_workflow_version_id=>wwv_flow_imp.id(13680274895120314)
,p_name=>unistr('Wydanie sprz\0119tu')
,p_static_id=>'New_8'
,p_display_sequence=>160
,p_activity_type=>'NATIVE_CREATE_TASK'
,p_attribute_01=>wwv_flow_imp.id(40420041245308443)
,p_attribute_05=>'APEX$WORKFLOW_DETAIL_PK'
,p_diagram=>'{"position":{"x":1390,"y":-60},"z":16}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(13680400175120316)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(13680338088120315)
,p_to_activity_id=>wwv_flow_imp.id(13680530956120317)
,p_diagram=>'{"source":{},"target":{},"vertices":[],"z":17,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(13680601166120318)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(13680530956120317)
,p_to_activity_id=>wwv_flow_imp.id(13681581564120327)
,p_diagram=>'{"source":{},"target":{},"vertices":[],"z":18,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(13680842686120320)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(13680721258120319)
,p_to_activity_id=>wwv_flow_imp.id(13682213648120334)
,p_diagram=>'{"source":{"name":"topLeft","args":{"dx":"54.545%","dy":"0%","rotate":true}},"target":{"name":"topLeft","args":{"dx":"50%","dy":"83.333%","rotate":true}},"vertices":[],"z":19,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(13681099624120322)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(13680903273120321)
,p_to_activity_id=>wwv_flow_imp.id(13683143034120343)
,p_diagram=>'{"source":{},"target":{"name":"topLeft","args":{"dx":"4.545%","dy":"50%","rotate":true}},"vertices":[],"z":20,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(13681295311120324)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(13681179025120323)
,p_to_activity_id=>wwv_flow_imp.id(13682746301120339)
,p_diagram=>'{"source":{},"target":{"name":"topLeft","args":{"dx":"100%","dy":"50%","rotate":true}},"vertices":[],"z":21,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(13681457677120326)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(13681355573120325)
,p_to_activity_id=>wwv_flow_imp.id(13682963534120341)
,p_diagram=>'{"source":{},"target":{"name":"topLeft","args":{"dx":"0%","dy":"50%","rotate":true}},"vertices":[],"z":22,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(13681620355120328)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(13681581564120327)
,p_to_activity_id=>wwv_flow_imp.id(13681806329120330)
,p_diagram=>'{"source":{},"target":{},"vertices":[],"z":23,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(13681928553120331)
,p_name=>'Nie (outcome = REJECTED)'
,p_transition_type=>'BRANCH'
,p_from_activity_id=>wwv_flow_imp.id(13681806329120330)
,p_to_activity_id=>wwv_flow_imp.id(13680721258120319)
,p_condition_type=>'EQUALS'
,p_condition_expr1=>'REJECTED'
,p_diagram=>'{"source":{},"target":{"name":"topLeft","args":{"dx":"54.545%","dy":"83.333%","rotate":true}},"vertices":[],"z":29,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(13682071234120332)
,p_name=>'Tak (outcome = APPROVED)'
,p_transition_type=>'BRANCH'
,p_from_activity_id=>wwv_flow_imp.id(13681806329120330)
,p_to_activity_id=>wwv_flow_imp.id(13682431264120336)
,p_condition_type=>'EQUALS'
,p_condition_expr1=>'APPROVED'
,p_diagram=>'{"source":{},"target":{},"vertices":[],"z":30,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(13682380051120335)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(13682213648120334)
,p_to_activity_id=>wwv_flow_imp.id(13682166251120333)
,p_diagram=>'{"source":{},"target":{},"vertices":[],"z":24,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(13682521478120337)
,p_name=>'Tak'
,p_transition_type=>'BRANCH'
,p_from_activity_id=>wwv_flow_imp.id(13682431264120336)
,p_to_activity_id=>wwv_flow_imp.id(13681355573120325)
,p_condition_expr1=>'TRUE'
,p_diagram=>'{"source":{},"target":{"name":"topLeft","args":{"dx":"0%","dy":"50%","rotate":true}},"vertices":[],"z":31,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(13682650871120338)
,p_name=>'Nie'
,p_transition_type=>'BRANCH'
,p_from_activity_id=>wwv_flow_imp.id(13682431264120336)
,p_to_activity_id=>wwv_flow_imp.id(13681179025120323)
,p_condition_expr1=>'FALSE'
,p_diagram=>'{"source":{"name":"topLeft","args":{"dx":"63.638%","dy":"100%","rotate":true}},"target":{"name":"topLeft","args":{"dx":"45.455%","dy":"12.5%","rotate":true}},"vertices":[],"z":32,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(13682841505120340)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(13682746301120339)
,p_to_activity_id=>wwv_flow_imp.id(13682431264120336)
,p_diagram=>'{"source":{},"target":{"name":"topLeft","args":{"dx":"13.641%","dy":"87.5%","rotate":true}},"vertices":[{"x":350,"y":0}],"z":25,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(13683006936120342)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(13682963534120341)
,p_to_activity_id=>wwv_flow_imp.id(13683342662120345)
,p_diagram=>'{"source":{},"target":{},"vertices":[],"z":26,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(13683225862120344)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(13683143034120343)
,p_to_activity_id=>wwv_flow_imp.id(13681776122120329)
,p_diagram=>'{"source":{},"target":{"name":"topLeft","args":{"dx":"33.333%","dy":"50%","rotate":true}},"vertices":[],"z":27,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(13683424600120346)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(13683342662120345)
,p_to_activity_id=>wwv_flow_imp.id(13680903273120321)
,p_diagram=>'{"source":{},"target":{"name":"topLeft","args":{"dx":"0%","dy":"50%","rotate":true}},"vertices":[],"z":28,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_participant(
 p_id=>wwv_flow_imp.id(13683610356120348)
,p_workflow_version_id=>wwv_flow_imp.id(13680274895120314)
,p_participant_type=>'ADMIN'
,p_name=>'New_1'
,p_identity_type=>'USER'
,p_value_type=>'SQL_QUERY'
,p_value=>'select LOGIN from APEX_MEETUP_USERS where IS_ADMIN = ''Y'''
);
wwv_flow_imp_shared.create_workflow_participant(
 p_id=>wwv_flow_imp.id(13683716494120349)
,p_workflow_version_id=>wwv_flow_imp.id(13680274895120314)
,p_participant_type=>'OWNER'
,p_name=>'New'
,p_identity_type=>'USER'
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':APEX$WORKFLOW_INITIATOR'
);
wwv_flow_imp.component_end;
end;
/
