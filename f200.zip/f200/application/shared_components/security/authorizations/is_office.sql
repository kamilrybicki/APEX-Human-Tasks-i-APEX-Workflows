prompt --application/shared_components/security/authorizations/is_office
begin
--   Manifest
--     SECURITY SCHEME: IS_OFFICE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.10'
,p_default_workspace_id=>30000567201644221
,p_default_application_id=>200
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXMEETUP'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(39948744311630036)
,p_name=>'IS_OFFICE'
,p_scheme_type=>'NATIVE_EXISTS'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from APEX_MEETUP_USERS',
' where LOGIN = :APP_USER',
'   and IS_OFFICE = ''Y'''))
,p_error_message=>unistr('Brak uprawnie\0144 pracownika biura')
,p_version_scn=>45639587536771
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/
