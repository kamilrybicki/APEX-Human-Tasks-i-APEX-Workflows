prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.10'
,p_default_workspace_id=>30000567201644221
,p_default_application_id=>200
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXMEETUP'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(30011028090811588)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
,p_version_scn=>45639589791652
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(30022660868811770)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39142358821156000)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'My orders'
,p_list_item_link_target=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'100,110'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39688715024152569)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'My tasks'
,p_list_item_link_target=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tasks'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'200'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39949613491652291)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Administration'
,p_list_item_link_target=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-gears'
,p_security_scheme=>wwv_flow_imp.id(39948506381629164)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'10000'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39978755139667826)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Unified Task List - Admin Tasks'
,p_list_item_link_target=>'f?p=&APP_ID.:10100:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-tasks'
,p_parent_list_item_id=>wwv_flow_imp.id(39949613491652291)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'10100'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(40000769012675114)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Workflow Console - Admin Workflows'
,p_list_item_link_target=>'f?p=&APP_ID.:10200:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-workflow'
,p_parent_list_item_id=>wwv_flow_imp.id(39949613491652291)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'10200'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(40065795199675352)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Workflow Console - Dashboard'
,p_list_item_link_target=>'f?p=&APP_ID.:10210:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-workflow'
,p_parent_list_item_id=>wwv_flow_imp.id(39949613491652291)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'10210'
);
wwv_flow_imp.component_end;
end;
/
