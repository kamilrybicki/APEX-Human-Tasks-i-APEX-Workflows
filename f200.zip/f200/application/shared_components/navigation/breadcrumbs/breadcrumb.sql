prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.10'
,p_default_workspace_id=>30000567201644221
,p_default_application_id=>200
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXMEETUP'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(30010511741811581)
,p_name=>'Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(30010782758811583)
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(39149127328156037)
,p_short_name=>'My orders'
,p_link=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
,p_page_id=>100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(39689691681152582)
,p_short_name=>'My tasks'
,p_link=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:::'
,p_page_id=>200
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(39950541363652300)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.:::'
,p_page_id=>10000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(39979655026667830)
,p_parent_id=>wwv_flow_imp.id(39950541363652300)
,p_short_name=>'Unified Task List - Admin Tasks'
,p_link=>'f?p=&APP_ID.:10100:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(40001624636675119)
,p_parent_id=>wwv_flow_imp.id(39950541363652300)
,p_short_name=>'Workflow Console - Admin Workflows'
,p_link=>'f?p=&APP_ID.:10200:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10200
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(40066605516675355)
,p_parent_id=>wwv_flow_imp.id(39950541363652300)
,p_short_name=>'Workflow Console - Dashboard'
,p_link=>'f?p=&APP_ID.:10210:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10210
);
wwv_flow_imp.component_end;
end;
/
