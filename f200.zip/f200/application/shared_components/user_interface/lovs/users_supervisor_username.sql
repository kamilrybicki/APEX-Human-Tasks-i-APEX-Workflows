prompt --application/shared_components/user_interface/lovs/users_supervisor_username
begin
--   Manifest
--     USERS.SUPERVISOR_USERNAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.10'
,p_default_workspace_id=>30000567201644221
,p_default_application_id=>200
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXMEETUP'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(39124102649149668)
,p_lov_name=>'USERS.SUPERVISOR_USERNAME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'APEX_MEETUP_USERS'
,p_return_column_name=>'LOGIN'
,p_display_column_name=>'SUPERVISOR_LOGIN'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45639587773504
);
wwv_flow_imp.component_end;
end;
/
