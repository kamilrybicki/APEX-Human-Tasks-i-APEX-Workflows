prompt --application/shared_components/user_interface/lovs/users_lov
begin
--   Manifest
--     USERS_LOV
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.10'
,p_default_workspace_id=>30000567201644221
,p_default_application_id=>200
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXMEETUP'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(38417095969513722)
,p_lov_name=>'USERS_LOV'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select full_name || '' ('' || login || '') - '' || ',
'            case login',
unistr('                when ''KRYBICKI''  then ''Pracownik wnioskuj\0105cy o sprz\0119t'''),
unistr('                when ''KNOWAK''    then ''Prze\0142o\017Cona Kamila Rybickiego'''),
'                when ''PKOWALSKI'' then ''CEO''',
'                when ''GWOJCIK''   then ''Biuro''',
'                when ''JKAMINSKA'' then ''Biuro''',
'            end  as display',
'      ,login as return',
'  from APEX_MEETUP_users',
'  order by case login',
'            when ''KRYBICKI'' then 1',
'            when ''KNOWAK'' then 2',
'            when ''GWOJCIK'' then 3',
'            when ''JKAMINSKA'' then 4',
'            else 5',
'           end asc, login'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'RETURN'
,p_display_column_name=>'DISPLAY'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45640870643158
);
wwv_flow_imp.component_end;
end;
/
