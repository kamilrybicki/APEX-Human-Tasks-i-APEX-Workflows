prompt --application/shared_components/logic/application_computations/ai_role_name_002
begin
--   Manifest
--     APPLICATION COMPUTATION: AI_ROLE_NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.10'
,p_default_workspace_id=>30000567201644221
,p_default_application_id=>200
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXMEETUP'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(42607615966317490)
,p_computation_sequence=>10
,p_computation_item=>'AI_ROLE_NAME'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'Brak'
,p_version_scn=>45641063188782
);
wwv_flow_imp.component_end;
end;
/
