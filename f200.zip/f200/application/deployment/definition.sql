prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 200
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.10'
,p_default_workspace_id=>30000567201644221
,p_default_application_id=>200
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXMEETUP'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(43643545287180984)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    for r_table_info in (',
'        select TABLE_NAME',
'          from USER_TABLES',
'         where TABLE_NAME in (''APEX_MEETUP_DICT_STATUSES'', ''APEX_MEETUP_USERS'', ''APEX_MEETUP_ITEMS'', ''APEX_MEETUP_ORDERS'')',
'    )',
'    loop',
'        execute immediate ''drop table '' || r_table_info.TABLE_NAME || '' cascade constraints'';',
'    end loop;',
'end;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
