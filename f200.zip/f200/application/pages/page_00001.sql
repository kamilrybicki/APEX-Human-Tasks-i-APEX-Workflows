prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.10'
,p_default_workspace_id=>30000567201644221
,p_default_application_id=>200
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXMEETUP'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'APEX Meetup'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11079671009642218)
,p_plug_name=>unistr('Wnioskowanie o sprz\0119t komputerowy - kroki procesu')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
unistr('  <li>Pracownik sk\0142ada wniosek o sprz\0119t.</li>'),
unistr('  <li>Wniosek trafia do akceptacji bezpo\015Bredniego prze\0142o\017Conego, kt\00F3ry mo\017Ce ten wniosek odrzuci\0107 lub zaakceptowa\0107.</li>'),
'  <ul>',
unistr('    <li>Odrzucenie wniosku ko\0144czy proces.</li>'),
'    <li>Zaakceptowanie wniosku kontynuuje proces.</li>',
'  </ul>',
'  <li>Automatyczne sprawdzenie stanu magazynowego.</li>',
'  <ul>',
unistr('    <li>Je\015Bli produktu nie ma na magazynie to uruchamia si\0119 oddzielny podproces do zamawiania towaru przez pracownik\00F3w biura. Po zako\0144czeniu podprocesu zamawiania, g\0142\00F3wny proces jest kontynuuowany.</li>'),
unistr('    <li>Je\015Bli produkt znajduje si\0119 na magazynie to nast\0119puje kontynuuacja procesu.</li>'),
'  </ul>',
unistr('  <li>Gdy sprz\0119t jest gotowy do wydania, wnioskuj\0105cy otrzymuje powiadomienie email z pro\015Bb\0105 o odebranie sprz\0119tu.</li>'),
unistr('  <li>Pracownik biura odznacza, \017Ce sprz\0119t zosta\0142 odebrany, co powoduje koniec procesu.</li>'),
'</ol>'))
,p_required_patch=>wwv_flow_imp.id(30009970487811572)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11080545138642227)
,p_plug_name=>unistr('Wnioskowanie o sprz\0119t komputerowy - diagram procesu')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30023433669811799)
,p_plug_name=>'APEX Meetup'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39001255062305402)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(30023433669811799)
,p_button_name=>'MAIL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Mail'
,p_required_patch=>wwv_flow_imp.id(30009970487811572)
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11080742985642229)
,p_name=>'P1_DIAGRAM'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(11080545138642227)
,p_prompt=>unistr('Wnioskowanie o sprz\0119t komputerowy - diagram procesu')
,p_source=>'#APP_FILES#Diagram procesu.png'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_grid_label_column_span=>0
,p_field_template=>2040785906935475274
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'URL')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39001131338305401)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SEND_EMAIL'
,p_process_name=>'New'
,p_attribute_01=>'&APP_EMAIL.'
,p_attribute_02=>'krybicki@pretius.com'
,p_attribute_06=>'test'
,p_attribute_07=>'wqeqweasdqwe'
,p_attribute_10=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(39001255062305402)
,p_required_patch=>wwv_flow_imp.id(30009970487811572)
,p_internal_uid=>39001131338305401
);
wwv_flow_imp.component_end;
end;
/
