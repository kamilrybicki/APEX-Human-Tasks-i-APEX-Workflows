prompt --application/pages/page_00210
begin
--   Manifest
--     PAGE: 00210
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.10'
,p_default_workspace_id=>30000567201644221
,p_default_application_id=>200
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXMEETUP'
);
wwv_flow_imp_page.create_page(
 p_id=>210
,p_name=>unistr('Wniosek o sprz\0119t - zmiana statusu')
,p_alias=>unistr('WNIOSEK-O-SPRZ\0118T-ZMIANA-STATUSU')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Wniosek o sprz\0119t - zmiana statusu')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39892358817250259)
,p_plug_name=>unistr('Wniosek o sprz\0119t - zmiana statusu')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'APEX_MEETUP_ORDERS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39899569222250303)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39899929046250304)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(39899569222250303)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39901717383250314)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(39899569222250303)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P210_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39902163863250315)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(39899569222250303)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P210_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39815814197693834)
,p_name=>'P210_APEX_TASK_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39816968958693845)
,p_name=>'P210_APEX_WORKFLOW_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(39892358817250259)
,p_item_source_plug_id=>wwv_flow_imp.id(39892358817250259)
,p_source=>'APEX_WORKFLOW_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39892679868250263)
,p_name=>'P210_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(39892358817250259)
,p_item_source_plug_id=>wwv_flow_imp.id(39892358817250259)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39893083441250271)
,p_name=>'P210_ITEM_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(39892358817250259)
,p_item_source_plug_id=>wwv_flow_imp.id(39892358817250259)
,p_prompt=>'Item Id'
,p_source=>'ITEM_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'ITEMS.NAME WITHOUT QUANTITY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID, NAME from ITEMS',
'order by NAME asc'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39893491283250276)
,p_name=>'P210_STATUS_CODE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(39892358817250259)
,p_item_source_plug_id=>wwv_flow_imp.id(39892358817250259)
,p_source=>'STATUS_CODE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39893827923250278)
,p_name=>'P210_QUANTITY'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(39892358817250259)
,p_item_source_plug_id=>wwv_flow_imp.id(39892358817250259)
,p_prompt=>'Quantity'
,p_source=>'QUANTITY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39894233552250279)
,p_name=>'P210_DESCRIPTION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(39892358817250259)
,p_item_source_plug_id=>wwv_flow_imp.id(39892358817250259)
,p_prompt=>'Description'
,p_source=>'DESCRIPTION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39942780821470949)
,p_name=>'P210_NEW_STATUS_CODE'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(39892358817250259)
,p_prompt=>'Status Code'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NAME',
'      ,CODE',
'  from APEX_MEETUP_DICT_STATUSES',
' where CODE = ''DELIVERED'' ',
'   and :P210_STATUS_CODE = ''READY_FOR_PICK_UP'''))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P210_STATUS_CODE'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(39942854553470950)
,p_computation_sequence=>10
,p_computation_item=>'P210_STATUS_CODE'
,p_computation_type=>'ITEM_VALUE'
,p_computation=>'P210_NEW_STATUS_CODE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(39900036991250304)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(39899929046250304)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39900802310250311)
,p_event_id=>wwv_flow_imp.id(39900036991250304)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39902943884250320)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(39892358817250259)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('Process form Wniosek o sprz\0119t - zmiana statusu')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>39902943884250320
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39815902807693835)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_MANAGE_TASK'
,p_process_name=>'Complete task - manage approach'
,p_attribute_01=>'COMPLETE_TASK'
,p_attribute_02=>'P210_APEX_TASK_ID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(39901717383250314)
,p_process_when=>':P210_APEX_TASK_ID is not null and :P210_STATUS_CODE = ''DELIVERED'''
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>39815902807693835
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(40432287669412301)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Complete task - API approach'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'APEX_HUMAN_TASK'
,p_attribute_04=>'COMPLETE_TASK'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(39901717383250314)
,p_process_when=>':P210_APEX_TASK_ID is not null and :P210_STATUS_CODE = ''DELIVERED'''
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_required_patch=>wwv_flow_imp.id(30009970487811572)
,p_internal_uid=>40432287669412301
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(40432371221412302)
,p_page_process_id=>wwv_flow_imp.id(40432287669412301)
,p_page_id=>210
,p_name=>'p_task_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P210_APEX_TASK_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(40432484313412303)
,p_page_process_id=>wwv_flow_imp.id(40432287669412301)
,p_page_id=>210
,p_name=>'p_outcome'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>20
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(40432565660412304)
,p_page_process_id=>wwv_flow_imp.id(40432287669412301)
,p_page_id=>210
,p_name=>'p_autoclaim'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>30
,p_value_type=>'EXPRESSION'
,p_value_language=>'SQL'
,p_value=>'true'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39903307510250321)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>39903307510250321
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39817211572693848)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Continue activity'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'APEX_WORKFLOW'
,p_attribute_04=>'CONTINUE_ACTIVITY'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(39901717383250314)
,p_process_when=>':P210_STATUS_CODE = ''DELIVERED'''
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_required_patch=>wwv_flow_imp.id(30009970487811572)
,p_internal_uid=>39817211572693848
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(39817350026693849)
,p_page_process_id=>wwv_flow_imp.id(39817211572693848)
,p_page_id=>210
,p_name=>'p_instance_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P210_APEX_WORKFLOW_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(39817491774693850)
,p_page_process_id=>wwv_flow_imp.id(39817211572693848)
,p_page_id=>210
,p_name=>'p_static_id'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'STATIC'
,p_value=>'WAITING_FOR_REQUESTOR'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(39937952925470901)
,p_page_process_id=>wwv_flow_imp.id(39817211572693848)
,p_page_id=>210
,p_name=>'p_activity_params'
,p_direction=>'IN'
,p_data_type=>'apex_application_global.vc_map'
,p_has_default=>false
,p_display_sequence=>30
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(39938040330470902)
,p_page_process_id=>wwv_flow_imp.id(39817211572693848)
,p_page_id=>210
,p_name=>'p_activity_status'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>40
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39902589789250318)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(39892358817250259)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form Wniosek o sprz\0119t - zmiana statusu')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>39902589789250318
);
wwv_flow_imp.component_end;
end;
/
